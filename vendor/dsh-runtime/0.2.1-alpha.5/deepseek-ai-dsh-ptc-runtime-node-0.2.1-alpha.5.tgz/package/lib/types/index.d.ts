import { Context } from '@deepseek-ai/cordis';
import { PtcRuntime } from '@deepseek-ai/dsh-ptc-runtime';
import type { PtcRunRequest, PtcRunResult, PtcRunSpec } from '@deepseek-ai/dsh-ptc-runtime';
import type { SandboxMode } from '@deepseek-ai/dsh-sandbox';
import type { Config } from './config.ts';
export type { Config } from './config.ts';
export type { LaunchConfig } from './launch.ts';
/** Node execution under file policy, with optional owner-scoped retained memory. */
export declare class NodePtcRuntime extends PtcRuntime {
    static inject: string[];
    static Config: import("@deepseek-ai/schemastery").default<Config>;
    readonly language = "typescript";
    readonly isolation = "process";
    private readonly inMemory?;
    private readonly processes;
    get programFormat(): 'function-body' | 'repl';
    get executionInstructions(): string;
    private readonly config;
    private readonly live;
    private disposed;
    constructor(ctx: Context, config: Config);
    get sandboxMode(): SandboxMode | undefined;
    release(owner: object): Promise<void>;
    get timeout(): {
        defaultMs: number;
        maxMs: number;
    };
    /**
     * Resolve directory, deadline and file policy for the selected execution mode.
     * @param request - Program, bindings, optional cwd/deadline, and resolved authority.
     * @returns Complete execution inputs with a capped numeric budget or an explicit null deadline.
     */
    resolve(request: PtcRunRequest): PtcRunSpec;
    /**
     * Run a resolved program under the configured execution mode.
     * Session mode changes cancel admitted calls before process launch as well as active programs.
     * @param spec - Inputs returned by resolve for the configured mode.
     * @returns Logs, JSON completion or failure; retained processes remain until release or invalidation.
     */
    run(spec: PtcRunSpec): Promise<PtcRunResult>;
    private execute;
}
export default NodePtcRuntime;
//# sourceMappingURL=index.d.ts.map