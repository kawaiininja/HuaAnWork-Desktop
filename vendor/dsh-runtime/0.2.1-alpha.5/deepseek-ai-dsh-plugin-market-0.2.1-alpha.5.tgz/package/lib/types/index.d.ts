/** Host reader of configured plugin market indexes for the Discover page and the `plugin_market` tool. */
import type { Context, Volatile } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { MarketIndexSummary, MarketListingEntry, MarketQuery, MarketSearchResult } from './types.ts';
export type * from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Configured plugin market index sources and their validated listings. */
        pluginMarket: PluginMarket;
    }
}
/** Index sources and fetch limits. */
export interface Config {
    /** Index URLs in display order; Settings and `setIndexes` write this field without remounting the service. */
    indexes: Volatile<string[]>;
    /** Deadline for one index fetch, including the body. */
    fetchTimeoutMs: number;
    /** Largest accepted index body in bytes. */
    maxBytes: number;
    /** Lifetime of a successfully read index document. */
    cacheTtlMs: number;
}
/** Fetches, validates, and caches configured market indexes; annotates entries with the profile's installation facts. */
export default class PluginMarket extends TypertRemoteService {
    private readonly config;
    static inject: string[];
    static Config: z<Schemastery.ObjectS<NoInfer<{
        indexes: z<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
        fetchTimeoutMs: z<number, number, "defined">;
        maxBytes: z<number, number, "defined">;
        cacheTtlMs: z<number, number, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        indexes: z<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
        fetchTimeoutMs: z<number, number, "defined">;
        maxBytes: z<number, number, "defined">;
        cacheTtlMs: z<number, number, "defined">;
    }>>, "plain">;
    private readonly lifetime;
    private readonly cache;
    private readonly pending;
    private readonly errors;
    private readonly entryId;
    constructor(ctx: Context, config: Config);
    /**
     * List the configured index sources without fetching them.
     * @returns every source in order, with the title of its last successful read and, when the last read failed, its error.
     */
    listIndexes(): MarketIndexSummary[];
    /**
     * Replace the configured index sources through Settings, without remounting this service.
     * `plugin-market/changed` announces the committed list. A URL already configured is kept as written, so a client can
     * add or remove sources beside one that `listIndexes` reports as unusable.
     * @param urls - index URLs in display order.
     * @throws {RemoteError} `plugin-market/invalid-index-url` for an invalid new URL or a repeated URL;
     * `plugin-market/settings-unavailable` without Settings or a profile entry.
     */
    setIndexes(urls: string[]): Promise<void>;
    /**
     * Return one page of the plugins of a configured index that match a query. Concurrent reads of a URL share one
     * fetch; a successful document is reused for `cacheTtlMs` unless `refresh` is set. Matching and ordering read only
     * the document; installation status and compatibility are computed for the returned page on every call.
     * @param url - a configured index URL.
     * @param query - text, filters, order, page, and whether to bypass the cached document.
     * @returns the index header, the page's plugins with each plugin's default version and installation status and each
     *   version's compatibility and install arguments, the number of matches, and the next page's offset.
     * @throws {RemoteError} `plugin-market/invalid-query`, `plugin-market/unknown-index`, `plugin-market/invalid-index-url`,
     *   `plugin-market/fetch-failed`, or `plugin-market/invalid-index`.
     */
    search(url: string, query: MarketQuery): Promise<MarketSearchResult>;
    /**
     * Read one plugin of a configured index, using the cached document as `search` does.
     * @param url - a configured index URL.
     * @param name - the plugin's package name.
     * @returns the plugin with its default version, installation status, and annotated versions; undefined when the
     *   index does not list it.
     * @throws {RemoteError} `plugin-market/unknown-index`, `plugin-market/invalid-index-url`, `plugin-market/fetch-failed`,
     *   or `plugin-market/invalid-index`.
     */
    entry(url: string, name: string): Promise<MarketListingEntry | undefined>;
    private document;
    /** Annotate plugins with the profile's bundles and exemptions as they are now. */
    private annotator;
    /**
     * The configured sources as written, each with the refusal that makes it unusable. Settings and profile files can
     * write any http(s) string, so every use validates instead of the schema; an unusable source is listed with its error
     * and never fetched, and a repeated URL counts once.
     */
    private sources;
    private configured;
    private fetchShared;
    private fetchIndex;
    /** Read the whole body, refusing it as soon as it exceeds `maxBytes`. */
    private readBody;
}
//# sourceMappingURL=index.d.ts.map