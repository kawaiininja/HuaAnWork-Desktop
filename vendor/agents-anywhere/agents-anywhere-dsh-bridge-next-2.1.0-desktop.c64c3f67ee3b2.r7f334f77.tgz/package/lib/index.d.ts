import { Context } from "@deepseek-ai/cordis";
import z from "@deepseek-ai/schemastery";
interface Config {
  dshHome?: string;
  apiBaseUrl?: string;
  stateRoot?: string;
  connectorSourceDir?: string;
  uvPath?: string;
}
declare const Config: z<Config>;
declare const name = "agents-anywhere-bridge-next";
declare function apply(ctx: Context, config: Config): void;
export { Config, apply, name };
//# sourceMappingURL=index.d.ts.map